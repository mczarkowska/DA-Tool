options(repos = "https://cloud.r-project.org/")

install.packages("rmarkdown")
install.packages("Hmisc")
install.packages("dplyr")
install.packages("e1071")
install.packages("ggpubr")
install.packages("ggplot2")
install.packages("car")
install.packages("dunn.test")
install.packages("FSA")
install.packages("PMCMRplus")
install.packages("cowplot")

library(Hmisc)
library(dplyr)
library(e1071)
library(ggplot2)
library(ggpubr)
library(car)
library(dunn.test)
library(FSA)
library(PMCMRplus)
library(cowplot)

args = commandArgs(trailingOnly=TRUE)
if (length(args)==0) {
  stop("NaleĹźy podaÄ co najmniej jeden argument wejĹciowy")
}

eData <- read.csv(file=args[1], header=TRUE, sep = ";", dec = ",")

#eData <- read.csv("przykladoweDane-Projekt(3).csv", sep = ";", dec = ",", header = TRUE)
#eData <- read.csv("przykladowe2Grupy.csv", sep = ";", dec = ",", header = TRUE)


braki <- function(eData) {
  informacje_braki <- list()
  
  unikalne_grupy <- unique(eData$grupa)
  
  for (grupa in unikalne_grupy) {
    indeksy <- which(eData$grupa == grupa)
    for (kolumna in names(eData)) {
      if (kolumna != "grupa" && is.numeric(eData[[kolumna]])) {
        
        mediana <- median(eData[indeksy, kolumna], na.rm = TRUE)
        
        indeksy_brakow <- which(is.na(eData[indeksy, kolumna]))
        
        if (length(indeksy_brakow) > 0) {
          eData[indeksy[indeksy_brakow], kolumna] <- mediana
          
          informacje_braki[[paste(kolumna, grupa, sep = "_")]] <- paste("Brakujące wartości:", length(indeksy_brakow), 
                                                                        "Zastąpiono medianą:", mediana, "Na indeksie:", indeksy_brakow,"w", grupa)
        }
      }
    }
  }
  
  for (nazwa in names(informacje_braki)) {
    cat(nazwa, ":", informacje_braki[[nazwa]], "\n")
  }
  
  return(eData)
}



boxploty <- function(gData){
  nKolumn <- colnames(gData)
  lBoxplots <- list()
  
  for (kolumna in nKolumn) {
    if (kolumna != "grupa" && is.numeric(gData[[kolumna]])){
      nazwa_pliku <- paste("boxplot_", kolumna, ".png", sep = "")
      
      png(nazwa_pliku, width = 800, height = 600)  # Dostosuj rozmiar wg potrzeb
      
      lBoxplots[[kolumna]] <- boxplot(gData[[kolumna]] ~ gData$grupa, 
                                      xlab = "Grupa", 
                                      ylab = kolumna,
                                      main = paste("Boxplot dla", kolumna))
      legend("topleft", 
             legend=c("Wartości odstające", "Mediana", "Wąsy"),
             fill=c("transparent", "grey", "transparent"),
             lty=c(0, 1, 2),      
             pch=c(1, NA, NA),    
             lwd=c(NA, 2, 1.5),   
             col=c("black", "black", "black"))
      
      
      dev.off()
      
    }
  }
  cat("\nWykresy obrazujące wartości odstające znajdują sie w folderze projektu \n")
  return(lBoxplots)
}

rOdstajacych <- function(lBoxplots, gData){
  nKolumn <- colnames(gData)
  wOdstajace <- list()
  oTabela <- list()
  
  for (kolumna in nKolumn) {
    if (kolumna != "grupa" && is.numeric(gData[[kolumna]])){
      
      odstaje <- lBoxplots[[kolumna]]$out
      
      indeksy_odstajacych <- which(gData[[kolumna]] %in% odstaje)
      
      indeksy_odstajacych <- indeksy_odstajacych[!duplicated(gData[[kolumna]][indeksy_odstajacych])]
      
      grupy_odstajacych <- gData$grupa[indeksy_odstajacych]
      
      wOdstajace[[kolumna]] <- list(dane = gData[[kolumna]], odstajace = odstaje)
      cat(paste("Wartosci odstajace dla kolumny", kolumna, "\n"))
      
      oTabela[[kolumna]] <- data.frame(Grupa = grupy_odstajacych, Wartość = odstaje)
      print(oTabela[[kolumna]])
    }
  }
  return(oTabela)
}

fCharakterystyki <- function(eData) {
  
  podsumowanie_wszystkich_kolumn <- data.frame()
  
  kolumny_do_podsumowania <- colnames(eData)[colnames(eData) != "grupa"]  # Pomijamy kolumnę 'grupa'
  
  for (kolumna in kolumny_do_podsumowania) {
    if (is.numeric(eData[[kolumna]])) {
      podsumowanie_kolumny <- eData %>%
        group_by(grupa) %>%
        summarise(
          Kolumna = kolumna,
          count = n(),
          mean = format(round(mean(.data[[kolumna]], na.rm = TRUE), 3), nsmall = 2),
          sd = format(round(sd(.data[[kolumna]], na.rm = TRUE), 3), nsmall = 2),
          median = format(round(median(.data[[kolumna]], na.rm = TRUE), 3), nsmall = 2),
          kurtoza = format(round(kurtosis(.data[[kolumna]], na.rm = TRUE), 3), nsmall = 2),
          skosnosc = format(round(skewness(.data[[kolumna]], na.rm = TRUE), 3), nsmall = 2),
          zakres = format(round(diff(range(.data[[kolumna]], na.rm = TRUE)), 3), nsmall = 2)
        )
      
      podsumowanie_wszystkich_kolumn <- bind_rows(podsumowanie_wszystkich_kolumn, podsumowanie_kolumny)
    }
  }
  
  kolumny_do_zmiany <- names(podsumowanie_wszystkich_kolumn)[names(podsumowanie_wszystkich_kolumn) != "grupa"]
  
  podsumowanie_wszystkich_kolumn[kolumny_do_zmiany] <- lapply(podsumowanie_wszystkich_kolumn[kolumny_do_zmiany], function(x) {
    if (is.character(x)) {
      return(gsub("\\.", ",", x))
    }
    return(x)
  })
  
  write.csv2(podsumowanie_wszystkich_kolumn, file = "wynik_charakterystyk.csv", row.names = FALSE, quote = TRUE)
  
  return(podsumowanie_wszystkich_kolumn)
}



fShapiro <- function(data){
  
  shapiroValues <- data.frame()  #
  
  kolumny_do_podsumowania <- colnames(data)[colnames(data) != "grupa"]  
  
  for (kolumna in kolumny_do_podsumowania) {
    if (is.numeric(data[[kolumna]])) {
      pvalueShapiro <- data %>%
        group_by(grupa) %>%
        summarise(
          Kolumna = kolumna,
          p.value = format(round(shapiro.test(.data[[kolumna]])$p.value, 3), nsmall = 2),
          statistic = format(round(shapiro.test(.data[[kolumna]])$statistic, 3), nsmall = 2),
          Zgodnosc_z_rozkladem_normalnym = ifelse(shapiro.test(.data[[kolumna]])$p.value > 0.05, "Zgodny", "Niezgodny")
        )
      
      shapiroValues <- bind_rows(shapiroValues, pvalueShapiro)
    }
  }
  
  return (shapiroValues)
  
}

fLevene <- function(data){
  kolumny_do_testu <- colnames(eData)[sapply(eData, is.numeric) & colnames(eData) != "grupa"]
  
  pvaluesLevene <- c()
  for (kolumna in  kolumny_do_testu) {
    if (is.numeric(data[[kolumna]])) {
      wzorzec <- paste(kolumna, "~ grupa")
      
      leveneTestResult <- leveneTest(as.formula(wzorzec), data = data)
      
      p_value <- leveneTestResult$"Pr(>F)"[1]
      
      pvaluesLevene <- c(pvaluesLevene, p_value)
      
      cat("---------------------------------------------------\n")
      cat("Test levene dla kolumny:", kolumna, "\n")
      cat("---------------------------------------------------\n")
      print(leveneTestResult)
      cat("P-wartość:", p_value, "\n\n")
      
      if (p_value > 0.05) {
        cat("Ho: Wariancje są homogeniczne (p-wartość > 0.05)\n")
      } else {
        cat("Ho: Wariancje nie są homogeniczne (p-wartość <= 0.05)\n")
      }
      cat("\n")
      
    }
  }
  return(pvaluesLevene)
  
}

testyPowyzej2 <- function(eData, shapiroValues, pvaluesLevene){
  
  kolumny_do_testu <- colnames(eData)[sapply(eData, is.numeric) & colnames(eData) != "grupa"]
  liczba_grup <- length(unique(eData$grupa))
  
  for (kolumna in kolumny_do_testu) {
    if (is.numeric(eData[[kolumna]])) {
      idx <- which(kolumny_do_testu == kolumna)
      cat("---------------------------------------------------\n")
      cat("Analiza dla kolumny:", kolumna, "\n")
      cat("---------------------------------------------------\n")
      currentShapiroValues <- shapiroValues[((idx-1)*liczba_grup+1):(idx*liczba_grup), "p.value"]
      
      
      if (all(currentShapiroValues > 0.05) && pvaluesLevene[idx] > 0.05) {
        cat("Shapiro-Wilk: Dane zgodne z rozkładem normalnym\n")
        cat("Levene: Wariancje są homogeniczne\n\n")
        
        wynik_anova <- aov(eData[[kolumna]] ~ eData$grupa)
        p_value_anova <- summary(wynik_anova)[[1]][["Pr(>F)"]][[1]]
        cat("Wyniki ANOVA:\n")
        print(summary(wynik_anova))
        
        if (p_value_anova > 0.05) {
          cat("\nBrak istotnych różnic między grupami.\n")
        } else {
          cat("\nIstnieją różnice między grupami.\n")
          
          cat("\nWyniki testu Tukeya:\n")
          tukey_results <- TukeyHSD(aov(eData[[kolumna]] ~ eData$grupa))
          print(tukey_results[[1]])
          if (any(tukey_results[[1]][, "p adj"] < 0.05)) {
            istotne <- which(tukey_results[[1]][, "p adj"] < 0.05)
            cat("\nIstnieje istotna statystycznie różnica między grupami, p.value < 0.05:", rownames(tukey_results[[1]])[istotne], "\n")
          }
        }
      } else {
        cat("Shapiro-Wilk: Dane niezgodne z rozkładem normalnym lub Levene\n\n")
        
        wynik_kruskala <- kruskal.test(eData[[kolumna]] ~ eData$grupa)
        p_value_kruskala <- wynik_kruskala$p.value
        cat("Wyniki Kruskala-Wallisa:\n")
        print(wynik_kruskala)
        
        if (p_value_kruskala > 0.05) {
          cat("\nBrak istotnych różnic między grupami.\n")
        } else {
          cat("\nIstnieją różnice między grupami.\n")
          
          dunn_data <- c(eData[[kolumna]])
          dunn_results <- dunnTest(dunn_data, eData$grupa)
          cat("\nWyniki testu Dunna (pomiędzy którymi grupami występują różnice):\n")
          print(dunn_results)
          if (any(dunn_results$res$P.adj < 0.05)) {
            istotne <- which(dunn_results$res$P.adj < 0.05)
            cat("\nIstnieje istotna statystycznie różnica między grupami, p.value < 0.05:", dunn_results$res$Comparison[istotne], "\n")
          }
        }
      }
      
      cat("\n\n")
    }
  }
}

testyDla2 <- function(eData, shapiroValues, pvaluesLevene) { 
  wyniki_testow <- list()
  
  # Kolumny do testu
  kolumny_do_testu <- colnames(eData)[sapply(eData, is.numeric) & colnames(eData) != "grupa"]
  
  liczba_grup <- length(unique(eData$grupa))
  
  for (kolumna in kolumny_do_testu) {
    if (is.numeric(eData[[kolumna]])) {
      idx <- which(kolumny_do_testu == kolumna)
      cat("\n")
      cat("---------------------------------------------------\n")
      cat("Analiza dla kolumny:", kolumna, "\n")
      cat("---------------------------------------------------\n")
      currentShapiroValues <- shapiroValues[((idx-1)*liczba_grup+1):(idx*liczba_grup), "p.value"]
      
      if (all(currentShapiroValues > 0.05) && pvaluesLevene[idx] > 0.05) {
        cat("Shapiro-Wilk: Dane zgodne z rozkładem normalnym\n")
        cat("Levene: Wariancje są homogeniczne\n")
        
        cat("\n")
        t_test_result_var_equal <- t.test(eData[[kolumna]] ~ eData$grupa, var.equal = TRUE)
        p_value_var_equal <- t_test_result_var_equal$p.value
        cat("Wyniki t-testu (var.equal = TRUE) dla kolumny:", kolumna, "\n")
        print(t_test_result_var_equal)
        
        if (p_value_var_equal < 0.05) {
          wyniki_testow[[kolumna]] <- list(t_test_var_equal = t_test_result_var_equal)
          cat("\nIstnieją istotne różnice między 2 grupami.\n")
        } else {
          cat("\nBrak istotnych różnic między 2 grupami.\n")
        }
        
      } else if(all(currentShapiroValues > 0.05) && pvaluesLevene[idx] < 0.05) {
        cat("Shapiro-Wilk: Dane zgodne z rozkładem normalnym\n")
        cat("Levene: Wariancje nie są homogeniczne\n")
        cat("\n")
        t_test_result_var_not_equal <- t.test(eData[[kolumna]] ~ eData$grupa, var.equal = FALSE)
        p_value_var_not_equal <- t_test_result_var_not_equal$p.value
        cat("Wyniki t-testu (var.equal = FALSE)", "\n")
        print(t_test_result_var_not_equal)
        
        if (p_value_var_not_equal < 0.05) {
          wyniki_testow[[kolumna]] <- list(t_test_var_not_equal = t_test_result_var_not_equal)
          cat("\nIstnieją istotne różnice między 2 grupami.\n")
        } else {
          cat("\nBrak istotnych różnic między 2 grupami.\n")
        }
        
      } else {
        cat("Shapiro-Wilk: Dane niezgodne z rozkładem normalnym")
        cat("\n")
        wilcox_test_result <- wilcox.test(eData[[kolumna]] ~ eData$grupa)
        p_value_wilcox <- wilcox_test_result$p.value
        cat("Wyniki testu Wilcoxona dla kolumny:", kolumna, "\n")
        print(wilcox_test_result)
        
        if (p_value_wilcox < 0.05) {
          wyniki_testow[[kolumna]] <- list(wilcox_test = wilcox_test_result)
          cat("\nIstnieją istotne różnice między 2 grupami.\n")
        } else {
          cat("\nBrak istotnych różnic między 2 grupami.\n")
        }
      }
    }
  }
  return(wyniki_testow)
}



okresl_kierunek_korelacji <- function(estimate) {
  if (estimate < 0) {
    return("Ujemna korelacja")
  } else if (estimate == 0) {
    return("Brak korelacji")
  } else if (estimate > 0) {
    return("Dodatnia korelacja")
  } else {
    return("Inny przypadek - mozliwy blad w danych")
  }
}

sila_korelacji <- function(estimate){
  if (-1 < estimate && estimate < -0.7) {
    return("bardzo silna korelacja ujemna")
  }  else if (-0.7 < estimate && estimate < -0.5) {
    return("silna korelacja ujemna")
  } else if (-0.5 < estimate && estimate < -0.3) {
    return("korelacja ujemna o średnim natężeniu")
  } else if (-0.3 < estimate && estimate < -0.2) {
    return("słaba korelacja ujemna")
  } else if (-0.2 < estimate && estimate < 0.2) {
    return("Brak korelacji")
  } else if (0.2 < estimate && estimate < 0.3) {
    return("słaba korelacja dodatnia")
  } else if (0.3 < estimate && estimate < 0.5) {
    return("korelacja dodatnia o średnim natężeniu")
  } else if (0.5 < estimate && estimate < 0.7) {
    return("silna korelacja dodatnia")
  } else if (0.7 < estimate && estimate < 1) {
    return("bardzo silna korelacja dodatnia")
  } else {
    return("Nie można określić kierunku korelacji - mozliwy blad danych")
  }
}


korelacja <- function(data) {
  wyniki_korelacji_lista <- list()
  kolumny_do_analizy <- colnames(data)[sapply(data, is.numeric) & colnames(data) != "grupa"]
  
  unikalne_grupy <- unique(data$grupa)
  kolory <- scales::hue_pal()(length(unikalne_grupy))
  mapa_kolorow <- setNames(kolory, unikalne_grupy)
  
  for (kolumna1 in kolumny_do_analizy) {
    for (kolumna2 in kolumny_do_analizy) {
      if (kolumna1 != kolumna2) {
        
        wyniki_korelacji <- data.frame()
        
        for (grupa_wew in unikalne_grupy) {
          dane_grupa <- data %>% filter(grupa == grupa_wew)
          
          if (is.numeric(dane_grupa[[kolumna1]]) && is.numeric(dane_grupa[[kolumna2]])) {
            
            shapiro1 <- shapiro.test(dane_grupa[[kolumna1]])
            shapiro2 <- shapiro.test(dane_grupa[[kolumna2]])
            
            if (shapiro1$p.value > 0.05 && shapiro2$p.value > 0.05) {
              wynik_korelacji <- cor.test(dane_grupa[[kolumna1]], dane_grupa[[kolumna2]], method = "pearson")
              metoda_korelacji <- "pearson"
            } else {
              wynik_korelacji <- cor.test(dane_grupa[[kolumna1]], dane_grupa[[kolumna2]], method = "spearman")
              metoda_korelacji <- "spearman"
            }
            
            wyniki_korelacji <- rbind(wyniki_korelacji, data.frame(
              Grupa = grupa_wew,
              Kolumna1 = kolumna1,
              Kolumna2 = kolumna2,
              P_Wartość = format(round(wynik_korelacji$p.value, 3), nsmall = 2),
              Współczynnik_Korelacji = format(round(wynik_korelacji$estimate, 3), nsmall = 2),
              Korelacja_Obecna = ifelse(wynik_korelacji$p.value < 0.05, "Tak", "Nie"),
              Kierunek_korelacji = okresl_kierunek_korelacji(wynik_korelacji$estimate),
              Siła_korelacji = sila_korelacji(wynik_korelacji$estimate)
            ))
          }
        }
        
          gg <- ggscatter(data, x = kolumna1, y = kolumna2, 
                          color = "grupa", fill = "grupa",
                          palette = mapa_kolorow,
                          add = "reg.line", conf.int = TRUE, 
                          cor.coef = TRUE, cor.method = metoda_korelacji)
          
          nazwa_pliku <- paste0("Wykres_", kolumna1, "_vs_", kolumna2, ".png")
          ggsave(nazwa_pliku, gg, width = 14, height = 10, units = "cm")
        
        wyniki_korelacji_lista[[paste0(kolumna1, "_vs_", kolumna2)]] <- wyniki_korelacji
      }
    }
  }
  
  cat("Wykresy korelacji znajdują się w folderze projektu")
  
  return(wyniki_korelacji_lista)
}






#Punkt 1.
#a) zastapienie brakow danych 
cat("\n1.Obsluga brakow danych\n")
eData<-braki(eData)
eData
cat("\n1.1Raport wartosci odstajacych\n")
#b) Wartosci odstajace - boxplot
gData <- eData %>%
  group_by(grupa)
#wizualizacja
boxplots <- boxploty(gData)
#raport wartosci odstajacych
OdstajaceTabela <- rOdstajacych(boxplots, gData) 

#Punkt 2
#charakterystyki
cat("\n2.Przeprowadzenie charakterystyk\n")
wynikCharakterystyk <- fCharakterystyki(eData)
wynikCharakterystyk

#Punkt3
#shapiro
cat("\n3.1Przeprowadzenie testu na zgodnosc z rozkladem normalnym\n")
shapiroValues <- fShapiro(eData)
shapiroValues

#wykresy gestosci
library(ggplot2)
library(RColorBrewer)

for (kolumna in colnames(eData)) {
  if (kolumna != "grupa" && is.numeric(eData[[kolumna]])) {
    nazwa_pliku <- paste("Wykres_gestosci_dla_", kolumna, ".png", sep = "")
    
    gg <- ggplot(eData, aes(x = !!sym(kolumna), color = grupa, fill = grupa)) +
      geom_density(alpha = 0.5) +
      scale_color_brewer(palette = "Accent") +
      scale_fill_brewer(palette = "Accent") +
      labs(title = paste("Wykres gęstości dla", kolumna))
    
    ggsave(gg, file = nazwa_pliku, width = 30, height = 15, units = "cm")
  }
}
cat("\nwykresy gestosci znajduja sie w pliku projektu\n")

#levene
cat("\n3.2Przeprowadzenie testu na wariancje homogeniczna\n")
pvaluesLevene <- fLevene(eData)

#testy ze wzgledu na ilosc grup
cat("3.3Przeprowadzenie testow statystycznych ze wzgledu na ilosc i rodzaj grup\n")
ileGrup <- length(unique(eData$grupa))
if(ileGrup > 2){
  testyPowyzej2(eData, shapiroValues, pvaluesLevene)
}else if(ileGrup == 2){
  testyDla2(eData, shapiroValues, pvaluesLevene)
}else{
  stop("Wprowadzone dane maja za mala liczbe grup badawczych do dalszej analizy.")
}

#test i wizualicja nieparamterycznych
cat("\n3.4Test i wizualizacja danych nieparamterycznych\n")
nazwyKolumn <- names(eData)
wykresy <- list()

for (kolumna in nazwyKolumn){
  if (kolumna != "grupa" && !(is.numeric(eData[[kolumna]]))){
    chisq_test_result <- chisq.test(eData$grupa, eData[[kolumna]])
    pvalueChisq <- chisq_test_result$p.value
    cat(paste("\nP-value dla testu chi-kwadrat dla kolumny:", kolumna,"\n"))
    cat("\njest równe:",pvalueChisq,"\n")
    
    tablica <- table(eData[[kolumna]], eData$grupa)
    
    nazwa_pliku <- paste("wykres_", kolumna, ".png", sep = "")
    wykresy[[kolumna]] <- nazwa_pliku
    
    png(nazwa_pliku)
    
    barplot(tablica,
            ylim = c(0, 22),
            beside = TRUE,
            col = c("#ffb3b3", "#b3d1ff"),
            xlab = "grupa",
            ylab = kolumna
    )
    
    unikalne_wartosci <- unique(eData[[kolumna]])
    
    legend("topright", legend = unikalne_wartosci, fill = c("#ffb3b3", "#b3d1ff"))
    
    text(1.5, 20, paste("p-value", round(pvalueChisq, digits = 3)))
    
    dev.off()
  }
}

cat("\nwykres/y danych nieparametrycznych znajduja sie w pliku projektu\n")

save(wykresy, file = "nazwy_wykresow.RData")



#Punkt4
# Wyświetl wyniki korelacji dla wszystkich grup
cat("\n4.Analiza korelacji dla wszystkich grup\n")
printKorelacja <- korelacja(eData)
print(printKorelacja)



rmarkdown::render("raport_podsumowujacy.Rmd")





